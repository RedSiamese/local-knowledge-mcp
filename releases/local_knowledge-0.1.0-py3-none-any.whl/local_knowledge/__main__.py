import local_knowledge

if __name__ == "__main__":
    local_knowledge.main()
